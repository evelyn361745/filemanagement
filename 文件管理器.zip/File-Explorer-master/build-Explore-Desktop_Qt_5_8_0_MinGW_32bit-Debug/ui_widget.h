/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLCDNumber>
#include <QtWidgets/QLabel>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QLabel *labLive;
    QLabel *labDateTime;
    QLCDNumber *lcdNumber;
    QLabel *labCPUMemory;
    QTableWidget *tableWidget;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QStringLiteral("Widget"));
        Widget->resize(761, 481);
        verticalLayout = new QVBoxLayout(Widget);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        labLive = new QLabel(Widget);
        labLive->setObjectName(QStringLiteral("labLive"));

        horizontalLayout->addWidget(labLive);

        labDateTime = new QLabel(Widget);
        labDateTime->setObjectName(QStringLiteral("labDateTime"));

        horizontalLayout->addWidget(labDateTime);


        verticalLayout->addLayout(horizontalLayout);

        lcdNumber = new QLCDNumber(Widget);
        lcdNumber->setObjectName(QStringLiteral("lcdNumber"));

        verticalLayout->addWidget(lcdNumber);

        labCPUMemory = new QLabel(Widget);
        labCPUMemory->setObjectName(QStringLiteral("labCPUMemory"));

        verticalLayout->addWidget(labCPUMemory);

        tableWidget = new QTableWidget(Widget);
        tableWidget->setObjectName(QStringLiteral("tableWidget"));

        verticalLayout->addWidget(tableWidget);


        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "\347\224\265\350\204\221\345\256\236\346\227\266\345\206\205\345\255\230\344\275\277\347\224\250\346\203\205\345\206\265", Q_NULLPTR));
        labLive->setText(QApplication::translate("Widget", "TextLabel", Q_NULLPTR));
        labDateTime->setText(QApplication::translate("Widget", "TextLabel", Q_NULLPTR));
        labCPUMemory->setText(QApplication::translate("Widget", "TextLabel", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
