/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableView>
#include <QtWidgets/QTreeView>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionOpen;
    QAction *actiontxt;
    QAction *actionword;
    QAction *actionexcel;
    QAction *actioncopy;
    QAction *actionpaste;
    QAction *actionrename;
    QAction *actiondelete;
    QWidget *centralWidget;
    QGridLayout *gridLayout;
    QHBoxLayout *horizontalLayout_8;
    QHBoxLayout *horizontalLayout_5;
    QPushButton *goBackButton_2;
    QPushButton *goButton_2;
    QPushButton *backButton_2;
    QHBoxLayout *horizontalLayout_6;
    QLineEdit *ShowExploreEdit_2;
    QComboBox *comboBox_2;
    QPushButton *updBTN_2;
    QHBoxLayout *horizontalLayout_7;
    QLineEdit *searchLineEdit_2;
    QSplitter *splitter;
    QWidget *layoutWidget_5;
    QVBoxLayout *verticalLayout_2;
    QListView *listViewExtra_2;
    QTreeView *treeView_2;
    QListView *listView_2;
    QTableView *tableView_2;
    QMenuBar *menuBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(1368, 726);
        actionOpen = new QAction(MainWindow);
        actionOpen->setObjectName(QStringLiteral("actionOpen"));
        actiontxt = new QAction(MainWindow);
        actiontxt->setObjectName(QStringLiteral("actiontxt"));
        actionword = new QAction(MainWindow);
        actionword->setObjectName(QStringLiteral("actionword"));
        actionexcel = new QAction(MainWindow);
        actionexcel->setObjectName(QStringLiteral("actionexcel"));
        actioncopy = new QAction(MainWindow);
        actioncopy->setObjectName(QStringLiteral("actioncopy"));
        actionpaste = new QAction(MainWindow);
        actionpaste->setObjectName(QStringLiteral("actionpaste"));
        actionrename = new QAction(MainWindow);
        actionrename->setObjectName(QStringLiteral("actionrename"));
        actiondelete = new QAction(MainWindow);
        actiondelete->setObjectName(QStringLiteral("actiondelete"));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        gridLayout = new QGridLayout(centralWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setSpacing(6);
        horizontalLayout_8->setObjectName(QStringLiteral("horizontalLayout_8"));
        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setSpacing(0);
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        horizontalLayout_5->setContentsMargins(5, -1, -1, -1);
        goBackButton_2 = new QPushButton(centralWidget);
        goBackButton_2->setObjectName(QStringLiteral("goBackButton_2"));
        goBackButton_2->setMinimumSize(QSize(31, 28));
        goBackButton_2->setMaximumSize(QSize(31, 28));
        goBackButton_2->setStyleSheet(QStringLiteral("border-image: url(:/new/icon/image/back1.png);"));
        goBackButton_2->setIconSize(QSize(26, 26));

        horizontalLayout_5->addWidget(goBackButton_2);

        goButton_2 = new QPushButton(centralWidget);
        goButton_2->setObjectName(QStringLiteral("goButton_2"));
        goButton_2->setMinimumSize(QSize(31, 28));
        goButton_2->setMaximumSize(QSize(31, 28));
        goButton_2->setStyleSheet(QLatin1String("border-image: url(:/new/icon/image/go_1.png);\n"
"image: url(:/new/icon/image/go_1.png);"));
        goButton_2->setIconSize(QSize(23, 23));

        horizontalLayout_5->addWidget(goButton_2);

        backButton_2 = new QPushButton(centralWidget);
        backButton_2->setObjectName(QStringLiteral("backButton_2"));
        backButton_2->setMinimumSize(QSize(31, 28));
        backButton_2->setMaximumSize(QSize(31, 28));
        backButton_2->setStyleSheet(QLatin1String("border-image: url(:/new/icon/image/shift_up1.png);\n"
"image: url(:/new/icon/image/shift_up1.png);"));
        backButton_2->setIconSize(QSize(20, 20));

        horizontalLayout_5->addWidget(backButton_2);


        horizontalLayout_8->addLayout(horizontalLayout_5);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setSpacing(0);
        horizontalLayout_6->setObjectName(QStringLiteral("horizontalLayout_6"));
        ShowExploreEdit_2 = new QLineEdit(centralWidget);
        ShowExploreEdit_2->setObjectName(QStringLiteral("ShowExploreEdit_2"));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(ShowExploreEdit_2->sizePolicy().hasHeightForWidth());
        ShowExploreEdit_2->setSizePolicy(sizePolicy);
        ShowExploreEdit_2->setMinimumSize(QSize(200, 31));

        horizontalLayout_6->addWidget(ShowExploreEdit_2);

        comboBox_2 = new QComboBox(centralWidget);
        comboBox_2->setObjectName(QStringLiteral("comboBox_2"));
        comboBox_2->setMinimumSize(QSize(21, 31));
        comboBox_2->setMaximumSize(QSize(21, 31));

        horizontalLayout_6->addWidget(comboBox_2);

        updBTN_2 = new QPushButton(centralWidget);
        updBTN_2->setObjectName(QStringLiteral("updBTN_2"));
        updBTN_2->setMinimumSize(QSize(31, 33));
        updBTN_2->setMaximumSize(QSize(31, 33));
        QIcon icon;
        icon.addFile(QStringLiteral(":/image/reload.png"), QSize(), QIcon::Normal, QIcon::Off);
        updBTN_2->setIcon(icon);
        updBTN_2->setIconSize(QSize(25, 25));

        horizontalLayout_6->addWidget(updBTN_2);


        horizontalLayout_8->addLayout(horizontalLayout_6);


        gridLayout->addLayout(horizontalLayout_8, 0, 0, 1, 1);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setSpacing(0);
        horizontalLayout_7->setObjectName(QStringLiteral("horizontalLayout_7"));
        horizontalLayout_7->setSizeConstraint(QLayout::SetMinimumSize);
        horizontalLayout_7->setContentsMargins(-1, -1, 5, -1);
        searchLineEdit_2 = new QLineEdit(centralWidget);
        searchLineEdit_2->setObjectName(QStringLiteral("searchLineEdit_2"));
        searchLineEdit_2->setMinimumSize(QSize(0, 31));
        searchLineEdit_2->setMaximumSize(QSize(331, 31));

        horizontalLayout_7->addWidget(searchLineEdit_2);


        gridLayout->addLayout(horizontalLayout_7, 0, 1, 1, 1);

        splitter = new QSplitter(centralWidget);
        splitter->setObjectName(QStringLiteral("splitter"));
        splitter->setCursor(QCursor(Qt::ArrowCursor));
        splitter->setContextMenuPolicy(Qt::DefaultContextMenu);
        splitter->setOrientation(Qt::Horizontal);
        splitter->setHandleWidth(8);
        splitter->setChildrenCollapsible(false);
        layoutWidget_5 = new QWidget(splitter);
        layoutWidget_5->setObjectName(QStringLiteral("layoutWidget_5"));
        verticalLayout_2 = new QVBoxLayout(layoutWidget_5);
        verticalLayout_2->setSpacing(0);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        listViewExtra_2 = new QListView(layoutWidget_5);
        listViewExtra_2->setObjectName(QStringLiteral("listViewExtra_2"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(listViewExtra_2->sizePolicy().hasHeightForWidth());
        listViewExtra_2->setSizePolicy(sizePolicy1);
        listViewExtra_2->setMinimumSize(QSize(160, 25));
        listViewExtra_2->setMaximumSize(QSize(16777215, 25));
        listViewExtra_2->setStyleSheet(QStringLiteral(""));

        verticalLayout_2->addWidget(listViewExtra_2);

        treeView_2 = new QTreeView(layoutWidget_5);
        treeView_2->setObjectName(QStringLiteral("treeView_2"));
        sizePolicy1.setHeightForWidth(treeView_2->sizePolicy().hasHeightForWidth());
        treeView_2->setSizePolicy(sizePolicy1);
        treeView_2->setMinimumSize(QSize(160, 0));
        treeView_2->viewport()->setProperty("cursor", QVariant(QCursor(Qt::ArrowCursor)));
        treeView_2->setMouseTracking(true);
        treeView_2->setContextMenuPolicy(Qt::DefaultContextMenu);
        treeView_2->setStyleSheet(QStringLiteral(""));

        verticalLayout_2->addWidget(treeView_2);

        splitter->addWidget(layoutWidget_5);
        listView_2 = new QListView(splitter);
        listView_2->setObjectName(QStringLiteral("listView_2"));
        sizePolicy1.setHeightForWidth(listView_2->sizePolicy().hasHeightForWidth());
        listView_2->setSizePolicy(sizePolicy1);
        listView_2->setMinimumSize(QSize(220, 0));
        listView_2->setStyleSheet(QStringLiteral(""));
        splitter->addWidget(listView_2);
        tableView_2 = new QTableView(splitter);
        tableView_2->setObjectName(QStringLiteral("tableView_2"));
        tableView_2->setMinimumSize(QSize(220, 0));
        splitter->addWidget(tableView_2);

        gridLayout->addWidget(splitter, 1, 0, 1, 2);

        MainWindow->setCentralWidget(centralWidget);
        splitter->raise();
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1368, 26));
        MainWindow->setMenuBar(menuBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", Q_NULLPTR));
        actionOpen->setText(QApplication::translate("MainWindow", "Open", Q_NULLPTR));
        actiontxt->setText(QApplication::translate("MainWindow", "txt", Q_NULLPTR));
        actionword->setText(QApplication::translate("MainWindow", "word", Q_NULLPTR));
        actionexcel->setText(QApplication::translate("MainWindow", "excel", Q_NULLPTR));
        actioncopy->setText(QApplication::translate("MainWindow", "copy", Q_NULLPTR));
        actionpaste->setText(QApplication::translate("MainWindow", "paste", Q_NULLPTR));
        actionrename->setText(QApplication::translate("MainWindow", "rename", Q_NULLPTR));
        actiondelete->setText(QApplication::translate("MainWindow", "delete", Q_NULLPTR));
        goBackButton_2->setText(QString());
        goButton_2->setText(QString());
        backButton_2->setText(QString());
        updBTN_2->setText(QString());
        searchLineEdit_2->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
