#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "searchthread.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    //以下为模型定义区域
    model = new QFileSystemModel;
    model ->setRootPath(":/");//本机根目录

    ui->treeView_2->setModel(model);
    ui->treeView_2->setHeaderHidden(true);

    //由于listView可能会被改变 故将listView的初始放在一个函数
    refreshView();
    //隐藏详细信息
    ui->treeView_2->setColumnHidden(1,true);
    ui->treeView_2->setColumnHidden(2,true);
    ui->treeView_2->setColumnHidden(3,true);

    //以下为变量定义区域
    allIndex.append(model->index(":/"));
    indexPoint = allIndex.size()-1;
    viewPoint = 0;

    ui->tableView_2->setShowGrid(false);
    ui->tableView_2->verticalHeader()->setVisible(false);
    ui->tableView_2->setModel(model);
    ui->treeView_2->header()->setStretchLastSection(true);
    ui->treeView_2->header()->setSortIndicator(0,Qt::AscendingOrder);
    ui->treeView_2->header()->setSortIndicatorShown(true);
    ui->treeView_2->header()->setSectionsClickable(true);
    ui->tableView_2->hide();

    QStandardItemModel *extraModel = new QStandardItemModel;
    QStandardItem *item = new QStandardItem(QStringLiteral("   我的电脑"));

    extraModel->appendRow(item);
    ui->listViewExtra_2->setModel(extraModel);
    ui->listViewExtra_2->setEditTriggers(QAbstractItemView::NoEditTriggers);

    ui->splitter->setStretchFactor(0,1); //调整比例 handle分离器调整
    ui->splitter->setStretchFactor(1,6);
    QPalette pal;
    pal.setColor(QPalette::Background,Qt::white);
    this->setPalette(pal);

    //以下为控件初始定义区域
    ui->searchLineEdit_2->setPlaceholderText(QStringLiteral("搜索本台电脑"));
    QAction *searchAction = new QAction(QIcon(":/image/search.png"),QStringLiteral("搜索"),this);
    ui->searchLineEdit_2->addAction(searchAction,QLineEdit::TrailingPosition);

    //以下为样式表区域

    ui->treeView_2->setStyleSheet("border-color:rgb(248,248,248); border-width:1px; border-style:solid; border-top-style:transparent");
    ui->goButton_2->setStyleSheet("QPushButton{border-image: url(:/image/go_1.png);}");
    ui->goBackButton_2->setStyleSheet("QPushButton{border-image: url(:/image/back1.png);}");
    ui->backButton_2->setStyleSheet("QPushButton{border-image: url(:/image/shift_up.png);}");

    //连接按钮事件与相应槽函数
    QObject::connect(ui->goButton_2,SIGNAL(clicked(bool)),this,SLOT(goButtonSlot()));
    QObject::connect(ui->goBackButton_2,SIGNAL(clicked(bool)),this,SLOT(goBackButtonSlot()));
    QObject::connect(ui->backButton_2,SIGNAL(clicked(bool)),this,SLOT(backButtonSlot()));

    QObject::connect(ui->updBTN_2,SIGNAL(clicked(bool)),this,SLOT(updateSlot()));
    QObject::connect(ui->listView_2,SIGNAL(doubleClicked(QModelIndex)),this,SLOT(doubleClickSlot(QModelIndex)));  //setRootIndex打开当前目录

    QObject::connect(ui->treeView_2,SIGNAL(doubleClicked(QModelIndex)) ,this,SLOT(doubleClickSlot(QModelIndex)));
    QObject::connect(ui->tableView_2,SIGNAL(doubleClicked(QModelIndex)),this,SLOT(doubleClickSlot(QModelIndex)));

    QObject::connect(searchAction,SIGNAL(triggered(bool)),this,SLOT(searchFileSlot()));



}

MainWindow::~MainWindow()
{
    delete ui;
}

//视图基本按钮

void MainWindow::refreshView()
{

    ui->listView_2->setModel(model);
    ui->listViewExtra_2->setStyleSheet("border-top-color:rgb(220,220,220); border-top-width:1px; border-top-style:solid; "
                                     "border-right-width:1px; border-right-color:rgb(248,248,248); border-right-style:solid;");

    ui->listView_2->setStyleSheet("border-top-color:rgb(220,220,220); border-width:1px; border-top-style:solid;");
    this->setContextMenuPolicy(Qt::DefaultContextMenu);
}

void MainWindow::juiceButton()
{
    if (indexPoint == allIndex.size()-1)
        ui->goButton_2->setStyleSheet("QPushButton{border-image: url(:/image/go_1.png);}");
    else
        ui->goButton_2->setStyleSheet("QPushButton{border-image: url(:/image/go_2.png);}");
    if (indexPoint>0)
        ui->goBackButton_2->setStyleSheet("QPushButton{border-image: url(:/image/back2.png);}");
    else
        ui->goBackButton_2->setStyleSheet("QPushButton{border-image: url(:/image/back1.png);}");
}

//前进功能
void MainWindow::goButtonSlot()
{
    if (indexPoint+1 != allIndex.size())
    {
        ui->listView_2->setRootIndex(allIndex.at(++indexPoint));
        QString filePath = model->filePath(allIndex.at(indexPoint));
        ui->ShowExploreEdit_2->setText(filePath);
        ui->searchLineEdit_2->setPlaceholderText(QStringLiteral("搜索“")+filePath+QStringLiteral("”"));
    }
    juiceButton();
    QModelIndex ti=ui->listView_2->currentIndex();
    ui->tableView_2->setRootIndex(ti);
}

//返回上一级功能
void MainWindow::backButtonSlot()
{
    indexNow = ui->listView_2->model()->parent(indexNow);
    ui->listView_2->setRootIndex(indexNow);
    ui->tableView_2->setRootIndex(indexNow);
    QString filePath = model->filePath(indexNow);
    ui->ShowExploreEdit_2->setText(filePath);
    ui->searchLineEdit_2->setPlaceholderText(QStringLiteral("搜索“")+filePath+QStringLiteral("”"));
}

//后退一步功能
void MainWindow::goBackButtonSlot()
{
    if (indexPoint > 0)
    {
        ui->listView_2->setRootIndex(allIndex.at(--indexPoint));
        QString filePath = model->filePath(allIndex.at(indexPoint));
        ui->ShowExploreEdit_2->setText(filePath);
        ui->searchLineEdit_2->setPlaceholderText(QStringLiteral("搜索“")+filePath+QStringLiteral("”"));
    }
    juiceButton();
    QModelIndex ti=ui->listView_2->currentIndex();
    ui->tableView_2->setRootIndex(ti);
}

//更新按钮功能
void MainWindow::updateSlot()
{
    ui->listView_2->setRootIndex(indexNow);
    ui->tableView_2->setRootIndex(indexNow);
}

//双击功能（不区分左右键）(增加了文件路径）
void MainWindow::doubleClickSlot(QModelIndex a)
{
    indexNow = a; //存储QModelIndex打开的文件的路径
    QFileInfo file = model->fileInfo(a);
    if(file.isDir()) //判断点击文件是否为文件夹，是则打开文件夹，否则是文件，打开文件内容
    {
    allIndex.remove(indexPoint+1,allIndex.size()-indexPoint-1);
    allIndex.append(a);
    indexPoint = allIndex.size()-1;
    ui->listView_2->setRootIndex(a);
    ui->tableView_2->setRootIndex(a);

    QString filePath = model->filePath(a);
    ui->ShowExploreEdit_2->setText(filePath);
    ui->searchLineEdit_2->setPlaceholderText(QStringLiteral("搜索“")+filePath+QStringLiteral("”"));
    juiceButton();
    }
    else
        QDesktopServices::openUrl(QUrl::fromLocalFile(file.absoluteFilePath()));//用对应程序打开文件
}


void MainWindow::clickCloseSlot()
{
    refreshView();
    searchFinishAction->setVisible(false);
    ui->searchLineEdit_2->clear();
    ui->listView_2->setRootIndex(allIndex.at(indexPoint));
    disconnect(ui->listView_2,SIGNAL(doubleClicked(QModelIndex)),this,SLOT(doubleClickInQstringList(QModelIndex)));
    connect(ui->listView_2,SIGNAL(doubleClicked(QModelIndex)),this,SLOT(doubleClickSlot(QModelIndex)));
}

void MainWindow::doubleClickInQstringList(QModelIndex a)
{
    clickCloseSlot();
    QString newPath = a.data().toString();
    int i;
    for (i=0; i<newPath.length(); i++)
    {
        if (newPath.at(i)=='\n')
            break;
    }
    newPath=newPath.remove(0,i+1);
    if (QFileInfo(newPath).isDir())
    ui->listView_2->setRootIndex(model->index(newPath));
    else if(QFileInfo(newPath).isFile())
    {
       QDesktopServices::openUrl(QUrl::fromLocalFile(newPath));
       ui->listView_2->setCurrentIndex(model->index(newPath));
    }
}

bool MainWindow::copyDirectoryFiles(const QString &fromDir, const QString &toDir)
{
    QDir sourceDir(fromDir);
    QDir targetDir(toDir);
    if(!targetDir.exists())
    {    // 如果目标目录不存在，则进行创建
        if(!targetDir.mkdir(targetDir.absolutePath()))
            return false;
    }
    QFileInfoList fileInfoList = sourceDir.entryInfoList();
    foreach(QFileInfo fileInfo, fileInfoList)
    {
        if(fileInfo.fileName() == "." || fileInfo.fileName() == "..")
            continue;
        if(fileInfo.isDir())
        {    // 当为目录时，递归的进行copy
            if(!copyDirectoryFiles(fileInfo.filePath(),
                                   targetDir.filePath(fileInfo.fileName())))
                return false;
        }
        else{            // 当允许覆盖操作时，将旧文件进行删除操作
            // 进行文件copy
            if(!QFile::copy(fileInfo.filePath(),
                            targetDir.filePath(fileInfo.fileName()))){
                return false;
            }
        }
    }
    return true;
}

//删除文件夹
bool MainWindow::removeFolderContent(QFileInfo fileList)
{
    if(fileList.isDir())
    {
        int childCount =0;
        QString dir = fileList.filePath();
        QDir thisDir(dir);
        childCount = thisDir.entryInfoList().count();
        QFileInfoList newFileList = thisDir.entryInfoList();
        if(childCount>2)
        {
            for(int i=0;i<childCount;i++)
            {
                if(newFileList.at(i).fileName().operator ==(".")|newFileList.at(i).fileName().operator ==(".."))
                {
                    continue;
                }
                removeFolderContent(newFileList.at(i));
            }
        }
        fileList.absoluteDir().rmpath(fileList.fileName());
    }
    else if(fileList.isFile())
    {
        fileList.absoluteDir().remove(fileList.fileName());
    }
    return true;
}

//查找同名文件（新建txt.word.exel用到）
bool MainWindow::findSameFile(QString filename,QString folderDir)
{

    QDir dir(folderDir);
    QFileInfoList fileList;
    QFileInfo curFile;
    if(!dir.exists())
    {return false;}//文件不存，则返回false
    fileList=dir.entryInfoList(QDir::Dirs|QDir::Files
                               |QDir::Readable|QDir::Writable
                               |QDir::Hidden|QDir::NoDotAndDotDot
                               ,QDir::Name);
    int infoNum=fileList.size();
    for(int i=infoNum-1;i>=0;i--)
    {
        curFile = fileList[i];
        if(0 == filename.compare(curFile.fileName()))
        {
            return true;
        }
    }
    return false;
}

//获取选中文件路径
void MainWindow::getPath(const QModelIndex &index)
{
    selectFileIndex = index;//获取选中文件
    isDelete = true;
}


//添加鼠标右键事件功能

void MainWindow::contextMenuEvent(QContextMenuEvent *)
{
    QMenu *menu = new QMenu(this);

    //添加右键菜单
    QAction *newDAction = new QAction(QStringLiteral("新文件夹"),this);
    QMenu *CreateFilemenu = new QMenu(QStringLiteral("新文件"),this);
    QAction *newTxtAction = new QAction(QStringLiteral("文本文档"),this);
    QAction *newExcelAction = new QAction(QStringLiteral("Excel文档"),this);
    QAction *newWordAction = new QAction(QStringLiteral("Word文档"),this);

    menu->addAction(newDAction);
    menu->addAction(CreateFilemenu->menuAction());

    CreateFilemenu->addAction(newTxtAction);
    CreateFilemenu->addAction(newExcelAction);
    CreateFilemenu->addAction(newWordAction);

    QAction *fileopen = menu->addAction(QStringLiteral("打开"));
    QAction *filecopy = menu->addAction(QStringLiteral("复制"));
    QAction *filepaste = menu->addAction(QStringLiteral("粘贴"));

    QAction *filedelete = menu->addAction(QStringLiteral("删除"));
    QAction *filerename = menu->addAction(QStringLiteral("重命名"));
    QAction *filedetail = menu->addAction(QStringLiteral("详情"));

    menu->move(cursor().pos());
    menu->show();
    if(!isCopy)
         filepaste->setEnabled(false);
     else
         filepaste->setEnabled(true);
    if(isDelete){
        filedelete->setEnabled(true);
    }else{
        filedelete->setEnabled(false);
    }
    //连接右键菜单按钮与相应功能槽函数
    connect(newDAction,SIGNAL(triggered()),this,SLOT(newDFile()));
    connect(newTxtAction,SIGNAL(triggered()),this,SLOT(newTxtFile()));
    connect(newExcelAction,SIGNAL(triggered()),this,SLOT(newExelFile()));
    connect(newWordAction,SIGNAL(triggered()),this,SLOT(newWordFile()));

    connect(fileopen,SIGNAL(triggered()),this,SLOT(fileopenslot()));
    connect(filedelete, SIGNAL(triggered(bool)), this, SLOT(filedeleteslot()));
    connect(filecopy, SIGNAL(triggered(bool)), this, SLOT(filecopyslot()));
    connect(filepaste, SIGNAL(triggered(bool)), this, SLOT(filepasteslot()));
    connect(filerename, SIGNAL(triggered(bool)), this, SLOT(filerenameslot()));
    connect(filedetail, SIGNAL(triggered(bool)), this, SLOT(filedetailslot()));

}

//新建TXT文件
void MainWindow::newTxtFile()
{
    QString path = model->filePath(indexNow)+"/";
    path.replace("/","\\");
    if(!findSameFile(tr("Note.txt"),path))
    {
        QFile file(path+tr("Note.txt"));
        file.open(QIODevice::WriteOnly);
        file.close();
    }
    else
    {
        int i = 1;
        QString num;
        while(1)
        {
            QString filename = tr("Note")+num.setNum(i)+".txt";
            if(!findSameFile(filename,path))
            {
                QFile file(path+filename);
                file.open(QIODevice::WriteOnly);
                file.close();
                return;
            }
            i++;
        }
    }
}

//新建Word文件
void MainWindow::newWordFile()
{
     QString path = model->filePath(indexNow)+"/";
     path.replace("/","\\");
    if(!findSameFile(tr("Word.doc"),path))
    {
        QFile file(path+tr("Word.doc"));
        file.open(QIODevice::WriteOnly);
        file.close();
    }
    else
    {
        int i = 1;
        QString num;
        while(1)
        {
            QString filename = tr("Word")+num.setNum(i)+".doc";
            if(!findSameFile(filename,path))
            {
                QFile file(path+filename);
                file.open(QIODevice::WriteOnly);
                file.close();
                return;
            }
            i++;
        }
    }
}

//新建Excel文件
void MainWindow::newExelFile()
{
     QString path = model->filePath(indexNow)+"/";
     path.replace("/","\\");
    if(!findSameFile(tr("Excel.xls"),path))
    {
        QFile file(path+tr("Excel.xls"));
        file.open(QIODevice::WriteOnly);
        file.close();
    }
    else
    {
        int i = 1;
        QString num;
        while(1)
        {
            QString filename = tr("Excel")+num.setNum(i)+".xls";
            if(!findSameFile(filename,path))
            {
                QFile file(path+filename);
                file.open(QIODevice::WriteOnly);
                file.close();
                return;
            }
            i++;
        }
    }
}

//新建文件夹
void MainWindow::newDFile()
{
    QModelIndex index = ui->listView_2->currentIndex();
    if (!index.isValid()) {
        return;
     }
     QString dirName = QInputDialog::getText(this,tr("新建"),tr("文件夹名"));
     if (!dirName.isEmpty()) {
         if (!model->mkdir(index,dirName).isValid()) {
              QMessageBox::warning(this,tr("创建文件夹"),tr("文件夹创建失败"));
          }
      }
}

//打开
void MainWindow::fileopenslot()
{
   QModelIndex a=ui->listView_2->currentIndex();
   doubleClickSlot(a);
}

//删除
void MainWindow::filedeleteslot()
{
   QModelIndex a =ui->listView_2->currentIndex();
    if (!a.isValid()) {
            return;
        }
        bool ok;
        if (model->fileInfo(a).isDir())
        {
            ok = model->rmdir(a);
        }
        else
        {
            ok = model->remove(a);
        }
        if (!ok)
        {
            QMessageBox::information(this,
                             tr("删除"),
                             tr("Failed to remove %1").arg(model->fileName(a)));
        }
}

//重命名
void MainWindow::filerenameslot()
{
    QModelIndex a=ui->listView_2->currentIndex();
    model->setReadOnly(false);
    QFileInfo f=model->fileInfo(a);
        if (!a.isValid()) {
            return;
        }
        QString newName= QInputDialog::getText(this,
                                                tr("重命名"),
                                                tr("新文件名"));
        QString startext = f.suffix();
        QFileInfo fi(newName);
        QString endext=fi.suffix();
        if (newName.isEmpty())
        {
            QMessageBox::warning(this,tr("Warning"),tr("文件名不能为空!!!"));
            return;
        }
        else
        {
           if(startext!=endext)
           {
               if(endext==NULL)
           {
                   newName=newName+"."+startext;
               model->setData(a, newName, Qt::EditRole);
           }
           else{
             QMessageBox::StandardButton res= QMessageBox::warning(NULL,
                                                        "warning", "后缀名改变可能会导致文件不可用！",
                                                        QMessageBox::Yes | QMessageBox::No, QMessageBox::Yes);
                        if(res==QMessageBox::No)
                          return;
                        if(res==QMessageBox::Yes)
                             //model->setData(index, value, Qt::EditRole);
           model->setData(a, newName, Qt::EditRole);
           }
           }
           else
                   model->setData(a,newName,Qt::EditRole);
        }
}

//文件信息
void MainWindow::filedetailslot()
{
    QDialog *finfo=new QDialog();
    QModelIndex fi=ui->listView_2->currentIndex();
    QFileInfo fin=model->fileInfo(fi);
    QLabel *name=new QLabel(tr("文件名 :"));
    QIcon ficon=model->fileIcon(fi);
    QLabel *type=new QLabel(tr("文件类型 :"));
    QLabel *path=new QLabel(tr("位置 :"));
    QLabel *size=new QLabel(tr("大小 :"));
    QLabel *creat=new QLabel(tr("创建时间 :"));
    QLabel *lasttime=new QLabel(tr("上次访问时间 :"));
    QLabel *lastmodified=new QLabel(tr("最近修改时间 :"));

    QLabel *nameline =new QLabel(fin.fileName());
    QLabel *typeline = new QLabel(model->type(fi));
    QLabel *pathline = new QLabel(fin.filePath());
    QLabel *sizeline = new QLabel(QString::number(fin.size()));
    QLabel *creatline = new QLabel(fin.created().toString("yyyy-MM-dd,hh:mm:ss"));
    QLabel *lTimeline = new QLabel(fin.lastRead().toString("yyyy-MM-dd,hh:mm:ss"));
    QLabel *lModifiedline = new QLabel(fin.lastModified().toString("yyyy-MM-dd,hh:mm:ss"));

    QVBoxLayout *fInfoName =new QVBoxLayout;
    fInfoName->addWidget(name);
    fInfoName->addWidget(type);
    fInfoName->addWidget(path);
    fInfoName->addWidget(size);
   // fInfoName->addItem(spaceitem1);
    fInfoName->addWidget(creat);
    fInfoName->addWidget(lasttime);
    fInfoName->addWidget(lastmodified);

    QVBoxLayout *fInfoData =new QVBoxLayout;
    fInfoData->addWidget(nameline);
    fInfoData->addWidget(typeline);
    fInfoData->addWidget(pathline);
    fInfoData->addWidget(sizeline);
   // fInfoData->addItem(spaceitem1);
    fInfoData->addWidget(creatline);
    fInfoData->addWidget(lTimeline);
    fInfoData->addWidget(lModifiedline);

    QHBoxLayout *datalayout =new QHBoxLayout;
    datalayout->addLayout(fInfoName);
    datalayout->addLayout(fInfoData);
    finfo->setLayout(datalayout);
    finfo->show();

}


void MainWindow::filecopyslot()
{
    copyIdex = ui->listView_2->currentIndex();
    isCopy = true;
    copyPath = model->fileInfo(copyIdex).absoluteFilePath();
    qDebug()<<copyPath;//"D:/yanjiushen/LeetCode.txt"

    int begin = copyPath.lastIndexOf("/")+1;
    int end = copyPath.lastIndexOf(".")-1;
    copyPostfixName = copyPath.mid(end+1);
    qDebug()<<copyPostfixName;//".txt"
    copyFileName = copyPath.mid(begin,end-begin+1);
    qDebug()<<copyFileName;//"LeetCode"
    isCopyFile = false;
    if(model->fileInfo(copyIdex).isFile())
    {
        isCopyFile = true;
    }
    qDebug()<<isCopyFile;//true
}

void MainWindow::filepasteslot()
{
    newPath = ui->ShowExploreEdit_2->text();
    qDebug()<<newPath;//"D:/yanjiushen/新建文件夹"
    QString filename = copyFileName + copyPostfixName;
    qDebug()<<filename;//"LeetCode.txt"
    if(isCopyFile)
    {
         if(findSameFile(filename,newPath))
         {//文件存在
              int i = 1;
              QString num;
              while(1)
              {
                 filename = copyFileName+tr("_Copy") + num.setNum(i)+copyPostfixName;
                 qDebug()<<filename;//"D:/yanjiushen/新建文件夹/LeetCode.txt"
                 if(!findSameFile(filename,newPath))
                 {
                     break;
                 }
                 i++;
             }//while(1)
         }
    newPath = newPath + "/" + filename;
    qDebug()<<newPath;
    QFile::copy(copyPath,newPath);
    }
    else
    {
        int begin = copyPath.lastIndexOf("/")+1;
        QString filename = copyPath.mid(begin);
        if(findSameFile(filename,newPath))
        {//文件夹存在
            int i = 1;
            QString num;
            while(1)
            {
                QString filename1 = filename+tr("_Copy") + num.setNum(i);
                if(!findSameFile(filename1,newPath))
                {
                    filename = filename1;
                    break;
                }
                i++;
             }//while(1)
        }
        newPath = newPath+"/"+filename;
        if(!copyDirectoryFiles(copyPath,newPath))
            qDebug()<<"no!";
   }

}


//搜索功能
void MainWindow::searchFileSlot()
{
    QString path = model->filePath(allIndex.at(indexPoint));
    QString searchText = ui->searchLineEdit_2->text();
    ui->searchLineEdit_2->setText(QStringLiteral("正在多线程搜索,可以进行其他操作"));
    SearchThread *searchThread1 = new SearchThread(path,searchText);
    connect(searchThread1,SIGNAL(sendData(QStringList)),this,SLOT(receQstring(QStringList)));
    searchThread1->start();
}

void MainWindow::receQstring(QStringList fileStringNew)
{
    if (!fileStringNew.isEmpty())
    {
    fileAndDirName = fileStringNew;
    ui->searchLineEdit_2->setText(QStringLiteral("搜索完毕，点击图标查看"));
    searchFinishAction = new QAction(QIcon(":/image/showSearch.png"),QStringLiteral("搜索完毕,显示"),this);
    ui->searchLineEdit_2->addAction(searchFinishAction,QLineEdit::TrailingPosition);
    connect(searchFinishAction,SIGNAL(triggered(bool)),this,SLOT(solveSraech()));
    }
    else
        ui->searchLineEdit_2->setText(QStringLiteral("搜索无此文件，请检查"));
}

void MainWindow::solveSraech()
{
    searchFinishAction->setIcon(QIcon(":/image/close.png"));
    searchFinishAction->setText(QStringLiteral("关闭搜索界面"));
    ui->searchLineEdit_2->setText(QStringLiteral("点击“×”关闭此页面"));
    QStringListModel *sModel = new QStringListModel;
    ui->listView_2->setModel(sModel);
    ui->listView_2->setViewMode(QListView::ListMode);
    ui->listView_2->setStyleSheet("border-top-color:rgb(220,220,220); border-top-width:1px; border-top-style:solid; "
                                "border-right-width:1px; border-right-color:rgb(248,248,248); border-right-style:solid;"
                                "font-size:20px");
    ui->listView_2->setIconSize(QSize(26,60));
    ui->listView_2->setGridSize(QSize(26,60));
    sModel->setStringList(fileAndDirName);
    this->setContextMenuPolicy(Qt::NoContextMenu);
    ui->listView_2->setEditTriggers(QAbstractItemView::NoEditTriggers);
    disconnect(searchFinishAction,SIGNAL(triggered(bool)),this,SLOT(solveSraech()));
    connect(searchFinishAction,SIGNAL(triggered(bool)),this,SLOT(clickCloseSlot()));
    disconnect(ui->listView_2,SIGNAL(doubleClicked(QModelIndex)),this,SLOT(doubleClickSlot(QModelIndex)));
    connect(ui->listView_2,SIGNAL(doubleClicked(QModelIndex)),this,SLOT(doubleClickInQstringList(QModelIndex)));
}
