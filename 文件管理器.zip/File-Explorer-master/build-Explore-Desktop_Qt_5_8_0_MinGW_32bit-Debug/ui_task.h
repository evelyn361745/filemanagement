/********************************************************************************
** Form generated from reading UI file 'task.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TASK_H
#define UI_TASK_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Task
{
public:
    QVBoxLayout *verticalLayout_2;
    QVBoxLayout *verticalLayout;
    QListWidget *listProcessWidget;
    QHBoxLayout *horizontalLayout;
    QPushButton *showProcessButton;
    QPushButton *startNewBoutton;
    QPushButton *killButton;

    void setupUi(QWidget *Task)
    {
        if (Task->objectName().isEmpty())
            Task->setObjectName(QStringLiteral("Task"));
        Task->resize(662, 421);
        verticalLayout_2 = new QVBoxLayout(Task);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        listProcessWidget = new QListWidget(Task);
        listProcessWidget->setObjectName(QStringLiteral("listProcessWidget"));

        verticalLayout->addWidget(listProcessWidget);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        showProcessButton = new QPushButton(Task);
        showProcessButton->setObjectName(QStringLiteral("showProcessButton"));

        horizontalLayout->addWidget(showProcessButton);

        startNewBoutton = new QPushButton(Task);
        startNewBoutton->setObjectName(QStringLiteral("startNewBoutton"));

        horizontalLayout->addWidget(startNewBoutton);

        killButton = new QPushButton(Task);
        killButton->setObjectName(QStringLiteral("killButton"));

        horizontalLayout->addWidget(killButton);


        verticalLayout->addLayout(horizontalLayout);


        verticalLayout_2->addLayout(verticalLayout);


        retranslateUi(Task);

        QMetaObject::connectSlotsByName(Task);
    } // setupUi

    void retranslateUi(QWidget *Task)
    {
        Task->setWindowTitle(QApplication::translate("Task", "\350\277\233\347\250\213\347\256\241\347\220\206", Q_NULLPTR));
        showProcessButton->setText(QApplication::translate("Task", "\345\210\267\346\226\260\346\230\276\347\244\272\350\277\233\347\250\213", Q_NULLPTR));
        startNewBoutton->setText(QApplication::translate("Task", "\350\277\220\350\241\214\346\226\260\350\277\233\347\250\213", Q_NULLPTR));
        killButton->setText(QApplication::translate("Task", "\347\273\223\346\235\237\350\277\233\347\250\213", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Task: public Ui_Task {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TASK_H
