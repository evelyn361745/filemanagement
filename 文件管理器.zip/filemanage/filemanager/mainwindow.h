#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QFileSystemModel>
#include <QStandardItemModel>
#include <QDirModel>
#include <QSplitter>
#include <QPalette>
#include <QDir>
#include <QVector>
#include <QtGui>
#include <QFile>
#include <QInputDialog>
#include <QMessageBox>
#include <QModelIndex>
#include <QLineEdit>
#include <QPushButton>
#include <QFileInfo>
#include <QLabel>
#include <QFileDialog>
#include <QThread>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private:
    Ui::MainWindow *ui;
    QFileSystemModel *model;
    QModelIndex indexNow;  //记录上一级文件夹
    QVector<QModelIndex> allIndex; //记录浏览记录
    QDirModel *q;
    int indexPoint; //用于记录打开的文件夹记录
    int viewPoint;  //表示为 什么视图
    QStringList fileAndDirName;  //记录搜索的变量
    QAction *searchFinishAction; //后面搜索按钮要加入
    void contextMenuEvent(QContextMenuEvent *event);
    void juiceButton();


  //  int findAllFileAndDir(const QString &dirPath);

    QModelIndex DirIndex;
    QModelIndex selectFileIndex;
    QList<QModelIndex>PathIdex;
    QModelIndex copyIdex;
    QModelIndex pasteIdex;
    bool isCopy;
    QString copyPath;
    QString copyFileName;
    QString copyPostfixName;
    QString newPath;

    bool isCopyFile;
    bool isDelete;

    bool findSameFile(QString filename,QString folderDir);//查找同名文件
    bool copyDirectoryFiles(const QString &fromDir, const QString &toDir);
    bool removeFolderContent(QFileInfo fileList);

private slots://槽函数

    //前进，后退，上移，搜索，更新槽函数
    void goButtonSlot();
    void goBackButtonSlot();
    void backButtonSlot();
    void updateSlot();
    void doubleClickSlot(QModelIndex);
    void searchFileSlot();


    void getPath(const QModelIndex &index);


    //鼠标右键槽函数
    void newTxtFile(void);
    void newExelFile(void);
    void newWordFile(void);
    void newDFile(void);
    void filedeleteslot();
    void filecopyslot();
    void filepasteslot();
    void filerenameslot();
    void fileopenslot();
    void filedetailslot();

    //刷新视图
    void refreshView();

    //接受thread的数据
    void doubleClickInQstringList(QModelIndex);
    void clickCloseSlot();
    void receQstring(QStringList);
    void solveSraech();

};

#endif // MAINWINDOW_H
