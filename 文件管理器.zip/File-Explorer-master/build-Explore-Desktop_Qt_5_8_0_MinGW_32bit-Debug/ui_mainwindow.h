/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableView>
#include <QtWidgets/QTreeView>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionOpen_O;
    QAction *actionClose_C;
    QAction *actionSave_S;
    QAction *actionSave_As_A;
    QAction *actionCopy;
    QAction *actionPaste;
    QAction *actionCut;
    QAction *actionDelete;
    QAction *actionRename;
    QAction *actionSearch;
    QAction *action_shuxing;
    QAction *actionTxt;
    QAction *actionWord;
    QAction *actionExel;
    QAction *actionList;
    QAction *actionBIcon;
    QAction *actionMIcon;
    QAction *actionSIcon;
    QAction *actionListinfo;
    QAction *actionInformation;
    QAction *actionLasttime;
    QAction *actionSize;
    QAction *action_helpsort;
    QAction *action_jpg;
    QAction *action_txt;
    QAction *action_rar;
    QAction *action_mp3;
    QAction *action_mp4;
    QAction *action_CPU;
    QAction *actionTask;
    QAction *actionAbout_Explorer;
    QWidget *centralWidget;
    QGridLayout *gridLayout;
    QHBoxLayout *horizontalLayout_2;
    QLineEdit *searchLineEdit;
    QHBoxLayout *horizontalLayout_4;
    QHBoxLayout *horizontalLayout_3;
    QPushButton *goBackButton;
    QPushButton *goButton;
    QPushButton *backButton;
    QHBoxLayout *horizontalLayout;
    QLineEdit *ShowExploreEdit;
    QComboBox *comboBox;
    QPushButton *updBTN;
    QSplitter *splitter;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QListView *listViewExtra;
    QTreeView *treeView;
    QListView *listView;
    QTableView *tableView;
    QMenuBar *menuBar;
    QMenu *menuW;
    QMenu *menuNew_N;
    QMenu *menu;
    QMenu *menuChakan;
    QMenu *seekMenu;
    QMenu *menu_2;
    QMenu *menu_3;
    QMenu *menu_4;
    QMenu *menu_5;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(1360, 760);
        MainWindow->setMinimumSize(QSize(900, 500));
        actionOpen_O = new QAction(MainWindow);
        actionOpen_O->setObjectName(QStringLiteral("actionOpen_O"));
        actionClose_C = new QAction(MainWindow);
        actionClose_C->setObjectName(QStringLiteral("actionClose_C"));
        actionSave_S = new QAction(MainWindow);
        actionSave_S->setObjectName(QStringLiteral("actionSave_S"));
        actionSave_As_A = new QAction(MainWindow);
        actionSave_As_A->setObjectName(QStringLiteral("actionSave_As_A"));
        actionCopy = new QAction(MainWindow);
        actionCopy->setObjectName(QStringLiteral("actionCopy"));
        actionPaste = new QAction(MainWindow);
        actionPaste->setObjectName(QStringLiteral("actionPaste"));
        actionCut = new QAction(MainWindow);
        actionCut->setObjectName(QStringLiteral("actionCut"));
        actionDelete = new QAction(MainWindow);
        actionDelete->setObjectName(QStringLiteral("actionDelete"));
        actionRename = new QAction(MainWindow);
        actionRename->setObjectName(QStringLiteral("actionRename"));
        actionSearch = new QAction(MainWindow);
        actionSearch->setObjectName(QStringLiteral("actionSearch"));
        action_shuxing = new QAction(MainWindow);
        action_shuxing->setObjectName(QStringLiteral("action_shuxing"));
        actionTxt = new QAction(MainWindow);
        actionTxt->setObjectName(QStringLiteral("actionTxt"));
        actionWord = new QAction(MainWindow);
        actionWord->setObjectName(QStringLiteral("actionWord"));
        actionExel = new QAction(MainWindow);
        actionExel->setObjectName(QStringLiteral("actionExel"));
        actionList = new QAction(MainWindow);
        actionList->setObjectName(QStringLiteral("actionList"));
        actionBIcon = new QAction(MainWindow);
        actionBIcon->setObjectName(QStringLiteral("actionBIcon"));
        actionMIcon = new QAction(MainWindow);
        actionMIcon->setObjectName(QStringLiteral("actionMIcon"));
        actionSIcon = new QAction(MainWindow);
        actionSIcon->setObjectName(QStringLiteral("actionSIcon"));
        actionListinfo = new QAction(MainWindow);
        actionListinfo->setObjectName(QStringLiteral("actionListinfo"));
        actionListinfo->setCheckable(true);
        actionInformation = new QAction(MainWindow);
        actionInformation->setObjectName(QStringLiteral("actionInformation"));
        actionLasttime = new QAction(MainWindow);
        actionLasttime->setObjectName(QStringLiteral("actionLasttime"));
        actionSize = new QAction(MainWindow);
        actionSize->setObjectName(QStringLiteral("actionSize"));
        action_helpsort = new QAction(MainWindow);
        action_helpsort->setObjectName(QStringLiteral("action_helpsort"));
        action_jpg = new QAction(MainWindow);
        action_jpg->setObjectName(QStringLiteral("action_jpg"));
        action_jpg->setCheckable(true);
        action_txt = new QAction(MainWindow);
        action_txt->setObjectName(QStringLiteral("action_txt"));
        action_txt->setCheckable(true);
        action_rar = new QAction(MainWindow);
        action_rar->setObjectName(QStringLiteral("action_rar"));
        action_rar->setCheckable(true);
        action_mp3 = new QAction(MainWindow);
        action_mp3->setObjectName(QStringLiteral("action_mp3"));
        action_mp3->setCheckable(true);
        action_mp4 = new QAction(MainWindow);
        action_mp4->setObjectName(QStringLiteral("action_mp4"));
        action_mp4->setCheckable(true);
        action_CPU = new QAction(MainWindow);
        action_CPU->setObjectName(QStringLiteral("action_CPU"));
        actionTask = new QAction(MainWindow);
        actionTask->setObjectName(QStringLiteral("actionTask"));
        actionAbout_Explorer = new QAction(MainWindow);
        actionAbout_Explorer->setObjectName(QStringLiteral("actionAbout_Explorer"));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        gridLayout = new QGridLayout(centralWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(1, -1, 1, 0);
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(0);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalLayout_2->setSizeConstraint(QLayout::SetMinimumSize);
        horizontalLayout_2->setContentsMargins(-1, -1, 5, -1);
        searchLineEdit = new QLineEdit(centralWidget);
        searchLineEdit->setObjectName(QStringLiteral("searchLineEdit"));
        searchLineEdit->setMinimumSize(QSize(0, 31));
        searchLineEdit->setMaximumSize(QSize(331, 31));

        horizontalLayout_2->addWidget(searchLineEdit);


        gridLayout->addLayout(horizontalLayout_2, 0, 1, 1, 1);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(0);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(5, -1, -1, -1);
        goBackButton = new QPushButton(centralWidget);
        goBackButton->setObjectName(QStringLiteral("goBackButton"));
        goBackButton->setMinimumSize(QSize(31, 28));
        goBackButton->setMaximumSize(QSize(31, 28));
        goBackButton->setStyleSheet(QStringLiteral("border-image: url(:/new/icon/image/back1.png);"));
        goBackButton->setIconSize(QSize(26, 26));

        horizontalLayout_3->addWidget(goBackButton);

        goButton = new QPushButton(centralWidget);
        goButton->setObjectName(QStringLiteral("goButton"));
        goButton->setMinimumSize(QSize(31, 28));
        goButton->setMaximumSize(QSize(31, 28));
        goButton->setStyleSheet(QLatin1String("border-image: url(:/new/icon/image/go_1.png);\n"
"image: url(:/new/icon/image/go_1.png);"));
        goButton->setIconSize(QSize(23, 23));

        horizontalLayout_3->addWidget(goButton);

        backButton = new QPushButton(centralWidget);
        backButton->setObjectName(QStringLiteral("backButton"));
        backButton->setMinimumSize(QSize(31, 28));
        backButton->setMaximumSize(QSize(31, 28));
        backButton->setStyleSheet(QLatin1String("border-image: url(:/new/icon/image/shift_up1.png);\n"
"image: url(:/new/icon/image/shift_up1.png);"));
        backButton->setIconSize(QSize(20, 20));

        horizontalLayout_3->addWidget(backButton);


        horizontalLayout_4->addLayout(horizontalLayout_3);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(0);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        ShowExploreEdit = new QLineEdit(centralWidget);
        ShowExploreEdit->setObjectName(QStringLiteral("ShowExploreEdit"));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(ShowExploreEdit->sizePolicy().hasHeightForWidth());
        ShowExploreEdit->setSizePolicy(sizePolicy);
        ShowExploreEdit->setMinimumSize(QSize(200, 31));

        horizontalLayout->addWidget(ShowExploreEdit);

        comboBox = new QComboBox(centralWidget);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setMinimumSize(QSize(21, 31));
        comboBox->setMaximumSize(QSize(21, 31));

        horizontalLayout->addWidget(comboBox);

        updBTN = new QPushButton(centralWidget);
        updBTN->setObjectName(QStringLiteral("updBTN"));
        updBTN->setMinimumSize(QSize(31, 33));
        updBTN->setMaximumSize(QSize(31, 33));
        QIcon icon;
        icon.addFile(QStringLiteral(":/new/icon/image/reload.png"), QSize(), QIcon::Normal, QIcon::Off);
        updBTN->setIcon(icon);
        updBTN->setIconSize(QSize(25, 25));

        horizontalLayout->addWidget(updBTN);


        horizontalLayout_4->addLayout(horizontalLayout);


        gridLayout->addLayout(horizontalLayout_4, 0, 0, 1, 1);

        splitter = new QSplitter(centralWidget);
        splitter->setObjectName(QStringLiteral("splitter"));
        splitter->setCursor(QCursor(Qt::ArrowCursor));
        splitter->setContextMenuPolicy(Qt::DefaultContextMenu);
        splitter->setOrientation(Qt::Horizontal);
        splitter->setHandleWidth(8);
        splitter->setChildrenCollapsible(false);
        layoutWidget = new QWidget(splitter);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setSpacing(0);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        listViewExtra = new QListView(layoutWidget);
        listViewExtra->setObjectName(QStringLiteral("listViewExtra"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(listViewExtra->sizePolicy().hasHeightForWidth());
        listViewExtra->setSizePolicy(sizePolicy1);
        listViewExtra->setMinimumSize(QSize(160, 25));
        listViewExtra->setMaximumSize(QSize(16777215, 25));
        listViewExtra->setStyleSheet(QStringLiteral(""));

        verticalLayout->addWidget(listViewExtra);

        treeView = new QTreeView(layoutWidget);
        treeView->setObjectName(QStringLiteral("treeView"));
        sizePolicy1.setHeightForWidth(treeView->sizePolicy().hasHeightForWidth());
        treeView->setSizePolicy(sizePolicy1);
        treeView->setMinimumSize(QSize(160, 0));
        treeView->viewport()->setProperty("cursor", QVariant(QCursor(Qt::ArrowCursor)));
        treeView->setMouseTracking(true);
        treeView->setContextMenuPolicy(Qt::DefaultContextMenu);
        treeView->setStyleSheet(QStringLiteral(""));

        verticalLayout->addWidget(treeView);

        splitter->addWidget(layoutWidget);
        listView = new QListView(splitter);
        listView->setObjectName(QStringLiteral("listView"));
        sizePolicy1.setHeightForWidth(listView->sizePolicy().hasHeightForWidth());
        listView->setSizePolicy(sizePolicy1);
        listView->setMinimumSize(QSize(220, 0));
        listView->setStyleSheet(QStringLiteral(""));
        splitter->addWidget(listView);
        tableView = new QTableView(splitter);
        tableView->setObjectName(QStringLiteral("tableView"));
        tableView->setMinimumSize(QSize(220, 0));
        splitter->addWidget(tableView);

        gridLayout->addWidget(splitter, 1, 0, 1, 2);

        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1360, 46));
        menuW = new QMenu(menuBar);
        menuW->setObjectName(QStringLiteral("menuW"));
        menuNew_N = new QMenu(menuW);
        menuNew_N->setObjectName(QStringLiteral("menuNew_N"));
        menu = new QMenu(menuBar);
        menu->setObjectName(QStringLiteral("menu"));
        menuChakan = new QMenu(menuBar);
        menuChakan->setObjectName(QStringLiteral("menuChakan"));
        seekMenu = new QMenu(menuChakan);
        seekMenu->setObjectName(QStringLiteral("seekMenu"));
        menu_2 = new QMenu(menuBar);
        menu_2->setObjectName(QStringLiteral("menu_2"));
        menu_3 = new QMenu(menuBar);
        menu_3->setObjectName(QStringLiteral("menu_3"));
        menu_4 = new QMenu(menuBar);
        menu_4->setObjectName(QStringLiteral("menu_4"));
        menu_5 = new QMenu(menuBar);
        menu_5->setObjectName(QStringLiteral("menu_5"));
        MainWindow->setMenuBar(menuBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        menuBar->addAction(menuW->menuAction());
        menuBar->addAction(menu_2->menuAction());
        menuBar->addAction(menu->menuAction());
        menuBar->addAction(menuChakan->menuAction());
        menuBar->addAction(menu_3->menuAction());
        menuBar->addAction(menu_4->menuAction());
        menuBar->addAction(menu_5->menuAction());
        menuW->addAction(menuNew_N->menuAction());
        menuW->addAction(actionOpen_O);
        menuW->addSeparator();
        menuNew_N->addAction(actionTxt);
        menuNew_N->addAction(actionWord);
        menuNew_N->addAction(actionExel);
        menu->addAction(action_shuxing);
        menuChakan->addAction(seekMenu->menuAction());
        seekMenu->addAction(actionList);
        seekMenu->addAction(actionBIcon);
        seekMenu->addAction(actionMIcon);
        seekMenu->addAction(actionSIcon);
        seekMenu->addAction(actionListinfo);
        menu_2->addAction(actionCopy);
        menu_2->addAction(actionPaste);
        menu_2->addAction(actionDelete);
        menu_2->addAction(actionRename);
        menu_3->addAction(action_helpsort);
        menu_3->addSeparator();
        menu_3->addAction(action_jpg);
        menu_3->addAction(action_txt);
        menu_3->addAction(action_rar);
        menu_3->addAction(action_mp3);
        menu_3->addAction(action_mp4);
        menu_4->addAction(action_CPU);
        menu_4->addAction(actionTask);
        menu_5->addAction(actionAbout_Explorer);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "windows\350\265\204\346\272\220\347\256\241\347\220\206\345\231\250", Q_NULLPTR));
        actionOpen_O->setText(QApplication::translate("MainWindow", "Open", Q_NULLPTR));
        actionClose_C->setText(QApplication::translate("MainWindow", "Close(C)", Q_NULLPTR));
        actionSave_S->setText(QApplication::translate("MainWindow", "Save(S)", Q_NULLPTR));
        actionSave_As_A->setText(QApplication::translate("MainWindow", "Save As(A)", Q_NULLPTR));
        actionCopy->setText(QApplication::translate("MainWindow", "Copy", Q_NULLPTR));
        actionPaste->setText(QApplication::translate("MainWindow", "Paste", Q_NULLPTR));
        actionCut->setText(QApplication::translate("MainWindow", "Cut", Q_NULLPTR));
        actionDelete->setText(QApplication::translate("MainWindow", "Delete", Q_NULLPTR));
        actionRename->setText(QApplication::translate("MainWindow", "Rename", Q_NULLPTR));
        actionSearch->setText(QApplication::translate("MainWindow", "Search", Q_NULLPTR));
        action_shuxing->setText(QApplication::translate("MainWindow", "Detail", Q_NULLPTR));
        actionTxt->setText(QApplication::translate("MainWindow", "Txt", Q_NULLPTR));
        actionWord->setText(QApplication::translate("MainWindow", "Word", Q_NULLPTR));
        actionExel->setText(QApplication::translate("MainWindow", "Exel", Q_NULLPTR));
        actionList->setText(QApplication::translate("MainWindow", "List", Q_NULLPTR));
        actionBIcon->setText(QApplication::translate("MainWindow", "BIcon", Q_NULLPTR));
        actionMIcon->setText(QApplication::translate("MainWindow", "MIcon", Q_NULLPTR));
        actionSIcon->setText(QApplication::translate("MainWindow", "SIcon", Q_NULLPTR));
        actionListinfo->setText(QApplication::translate("MainWindow", "Listinfo", Q_NULLPTR));
        actionInformation->setText(QApplication::translate("MainWindow", "Information", Q_NULLPTR));
        actionLasttime->setText(QApplication::translate("MainWindow", "lasttime", Q_NULLPTR));
        actionSize->setText(QApplication::translate("MainWindow", "size", Q_NULLPTR));
        action_helpsort->setText(QApplication::translate("MainWindow", "\346\237\245\347\234\213\345\270\256\345\212\251", Q_NULLPTR));
        action_jpg->setText(QApplication::translate("MainWindow", "\345\233\276\347\211\207(jpg\343\200\201png\343\200\201jpge\357\274\211", Q_NULLPTR));
        action_txt->setText(QApplication::translate("MainWindow", "\346\226\207\346\234\254(txt,word,excle,ppt)", Q_NULLPTR));
        action_rar->setText(QApplication::translate("MainWindow", "\345\216\213\347\274\251\346\226\207\346\241\243(rar,zip)", Q_NULLPTR));
        action_mp3->setText(QApplication::translate("MainWindow", "\351\237\263\344\271\220(mp3,wav,m4a)", Q_NULLPTR));
        action_mp4->setText(QApplication::translate("MainWindow", "\350\247\206\351\242\221(mp4,avi,rmvb)", Q_NULLPTR));
        action_CPU->setText(QApplication::translate("MainWindow", "\346\237\245\347\234\213\347\224\265\350\204\221\345\206\205\345\255\230\344\275\277\347\224\250\346\203\205\345\206\265", Q_NULLPTR));
        actionTask->setText(QApplication::translate("MainWindow", "\346\237\245\347\234\213\350\277\233\347\250\213", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        actionTask->setToolTip(QApplication::translate("MainWindow", "task", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        actionAbout_Explorer->setText(QApplication::translate("MainWindow", "About Explorer", Q_NULLPTR));
        searchLineEdit->setText(QString());
        goBackButton->setText(QString());
        goButton->setText(QString());
        backButton->setText(QString());
        updBTN->setText(QString());
        menuW->setTitle(QApplication::translate("MainWindow", "\346\226\207\344\273\266", Q_NULLPTR));
        menuNew_N->setTitle(QApplication::translate("MainWindow", "New", Q_NULLPTR));
        menu->setTitle(QApplication::translate("MainWindow", "    \350\256\241\347\256\227\346\234\272", Q_NULLPTR));
        menuChakan->setTitle(QApplication::translate("MainWindow", "    \346\237\245\347\234\213", Q_NULLPTR));
        seekMenu->setTitle(QApplication::translate("MainWindow", "\346\233\264\346\224\271\346\230\276\347\244\272\346\226\271\345\274\217", Q_NULLPTR));
        menu_2->setTitle(QApplication::translate("MainWindow", "    \347\274\226\350\276\221", Q_NULLPTR));
        menu_3->setTitle(QApplication::translate("MainWindow", "    \350\277\207\346\273\244\345\231\250\345\212\237\350\203\275", Q_NULLPTR));
        menu_4->setTitle(QApplication::translate("MainWindow", "    \344\273\273\345\212\241\347\256\241\347\220\206\345\231\250", Q_NULLPTR));
        menu_5->setTitle(QApplication::translate("MainWindow", "   \345\205\263\344\272\216\n"
"", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
