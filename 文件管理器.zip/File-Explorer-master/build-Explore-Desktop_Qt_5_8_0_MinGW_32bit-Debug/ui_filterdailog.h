/********************************************************************************
** Form generated from reading UI file 'filterdailog.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FILTERDAILOG_H
#define UI_FILTERDAILOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_FilterDailog
{
public:
    QVBoxLayout *verticalLayout_2;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *FilterDailog)
    {
        if (FilterDailog->objectName().isEmpty())
            FilterDailog->setObjectName(QStringLiteral("FilterDailog"));
        FilterDailog->resize(264, 143);
        verticalLayout_2 = new QVBoxLayout(FilterDailog);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        label = new QLabel(FilterDailog);
        label->setObjectName(QStringLiteral("label"));

        verticalLayout->addWidget(label);

        buttonBox = new QDialogButtonBox(FilterDailog);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        verticalLayout->addWidget(buttonBox);


        verticalLayout_2->addLayout(verticalLayout);


        retranslateUi(FilterDailog);
        QObject::connect(buttonBox, SIGNAL(accepted()), FilterDailog, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), FilterDailog, SLOT(reject()));

        QMetaObject::connectSlotsByName(FilterDailog);
    } // setupUi

    void retranslateUi(QDialog *FilterDailog)
    {
        FilterDailog->setWindowTitle(QApplication::translate("FilterDailog", "Dialog", Q_NULLPTR));
        label->setText(QApplication::translate("FilterDailog", "\350\277\231\346\230\257\344\270\200\344\270\252\346\210\221\344\273\254\345\242\236\345\212\240\347\232\204\345\212\237\350\203\275\357\274\232\350\277\207\346\273\244\345\231\250\357\274\214\n"
"\351\200\232\350\277\207\350\277\207\346\273\244\345\231\250\357\274\214\344\275\240\345\217\257\344\273\245\345\234\250\346\265\217\350\247\210\346\226\207\344\273\266\347\232\204\n"
"\346\227\266\345\200\231\345\217\252\347\234\213\345\210\260\344\275\240\346\203\263\350\246\201\347\232\204\346\226\207\344\273\266\346\240\274\345\274\217\357\274\214\345\205\266\n"
"\344\275\231\346\226\207\344\273\266\345\260\206\344\270\215\344\274\232\345\207\272\347\216\260\345\234\250\347\225\214\351\235\242\344\270\255\343\200\202", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class FilterDailog: public Ui_FilterDailog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FILTERDAILOG_H
